<?php get_header(); ?>
<div class="contenedor">

    <div id="left" class="eleven columns" >
        <div class="post">
            <div class="title">
                <h2>Sin Restuldaos</h2>
            </div>
            <div class="entry"><p>Lo sentimos mucho, pero la página solicitada no se ha encontrado! Es posible que se haya movido o eliminado.</p></div>
        </div>
    </div>
    <?php get_sidebar(); ?>
</div>
<?php get_footer(); ?>