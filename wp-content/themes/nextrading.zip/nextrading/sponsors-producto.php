<h1>Las mejores marcas del mercado.</h1>
<ul class="sponsors-producto_list">
    <li>
        <a href="<?php echo of_get_option("w2f_sponsor_url_1") ?>" target="_blank">
            <img src="<?php echo of_get_option("w2f_sponsor_img_1") ?>" style="vertical-align:bottom;" />
        </a>
    </li>			
    <li>
        <a href="<?php echo of_get_option("w2f_sponsor_url_2") ?>" target="_blank">
            <img src="<?php echo of_get_option("w2f_sponsor_img_2") ?>" style="vertical-align:bottom;" />
        </a>
    </li>			
    <li>
        <a href="<?php echo of_get_option("w2f_sponsor_url_3") ?>" target="_blank">
            <img src="<?php echo of_get_option("w2f_sponsor_img_3") ?>" style="vertical-align:bottom;" />
        </a>
    </li>			
    <li>
        <a href="<?php echo of_get_option("w2f_sponsor_url_4") ?>" target="_blank">
            <img src="<?php echo of_get_option("w2f_sponsor_img_4") ?>" style="vertical-align:bottom;" />
        </a>
    </li>			

    <div class="clear"></div>
</ul>
